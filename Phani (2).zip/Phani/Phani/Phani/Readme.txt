*******************HOME GYM WEBSITE**************
Home Gym Website 

This website consits of different connectivity webpages which mainly tells about the home gym equipment.

Process to follow to work with the website :

1) firstly open index.html page use any suitable browser which is the main page of the website.

2)click on explore to login and register page which are connected to mysql database.

3)the webpage consists of different interlinked pages which tells about the home gym equipment and gym needs.

4)it consits of a contact page where we can enter the email id and it will store in mysql database.

5)keep each and every file in the same floder..

6) WE used html,css, js..



*******************END*****************

